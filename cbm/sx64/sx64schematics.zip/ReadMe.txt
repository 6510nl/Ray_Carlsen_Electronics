Commodore SX 64 Portable Computer Schematics
--------------------------------------------

This archive contains a scanned version of the complete Commodore SX 64
Portable Computer Schematics. The book is marked as CBM Part No. 314001-05.

The PDF is in Letter format with all the double sized diagram pages in Ledger
format, just as the original. The width on the Front and Back covers is
slightly oversized, also just as the original.
The original was in near perfect condition, but due to the poor quality
of the original print, some of the scanned pages look somewhat poor. Blame
CBM, not me ;-)

I hope this document can be of some use to you.


2007-04-10, Devia/Ancients
